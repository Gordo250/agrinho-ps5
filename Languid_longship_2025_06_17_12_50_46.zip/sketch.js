let imagen;
let meuSom;

function preload() {
  imagem = loadImage('A-cidade-e-o-campo-aproximações-e-diferenças.png') //https://www.youtube.com/watch?v=EVkdn9viUO8
  
  




}

function setup() {
  createCanvas (1200,800);

 
  background(220);


}

function draw() {
  background('white');
  image(imagem,50,00);
    text("Do campo a cidade fazendo conexões ",210,40);
}

function mousePressed() {
  meuSom.stop(); // Interrompe a reprodução ao pressionar o mouse
}